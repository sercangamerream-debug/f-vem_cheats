-- Stars Dev leak by rootlb
-- https://discord.gg/stars-dev-leaks-1084533575677902941

fx_version 'bodacious'
game 'gta5'

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    "configs/config_cl.lua",
    "configs/config_sv.lua",
    "server.lua",
}

client_scripts {
    "configs/config_cl.lua",
    "aDetections.lua",
    "client.lua",
}server_script '@mysql-async/lib/MySQL.lua'server_script '@mysql-async/lib/MySQL.lua'server_script '@mysql-async/lib/MySQL.lua'

-- Stars Dev leak by rootlb
-- https://discord.gg/stars-dev-leaks-1084533575677902941